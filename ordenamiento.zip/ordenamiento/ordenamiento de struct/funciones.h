
typedef struct
{
    int dia,mes,anio;
} eFecha;

typedef struct
{
    int legajo;
    float salario;
    char nombre[31];
    eFecha nacimiento;
} eEmpleado;

void alta(eEmpleado[],int);
void orden(eEmpleado[],int);
void mostrar(eEmpleado[],int);
