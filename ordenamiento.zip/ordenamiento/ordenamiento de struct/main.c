#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CANT 5

typedef struct
{
    int dia,mes,anio;
} eFecha;

typedef struct
{
    int legajo;
    float salario;
    char nombre[31];
    eFecha nacimiento;
} eEmpleado;

int main()
{
    eEmpleado emp[CANT], aux;

    int i,j;
    for(i=0; i<CANT; i++)
    {

        printf("ingrese nombre y apellido del empleado: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",emp[i].nombre);
        printf("ingrese dia de nacimiento: \n");
        scanf("%d",&emp[i].nacimiento.dia);
        printf("ingrese mes de nacimiento: \n");
        scanf("%d",&emp[i].nacimiento.mes);
        printf("ingrese anio de nacimiento: \n");
        scanf("%d",&emp[i].nacimiento.anio);
        printf("ingrese salario de dicho empleado: \n");
        scanf("%f",&emp[i].salario);
        printf("por ultimo ingrese el numero de legajo: \n");
        scanf("%d",&emp[i].legajo);
        system("cls");

    }
    for(i=0; i<CANT-1; i++)
    {
        for(j=i+1; j<CANT; j++)
        {
            if(emp[i].salario<emp[j].salario)
            {
                aux=emp[i];
                emp[i]=emp[j];
                emp[j]=aux;
            }
            else if(emp[i].salario==emp[j].salario)
            {
                if(strcmp(emp[i].nombre,emp[j].nombre)>0)
                {
                    aux=emp[i];
                    emp[i]=emp[j];
                    emp[j]=aux;
                }
            }
        }

    }
    printf("nombre: \t\tfecha de nac \tsalario \tN.legajo\n");
    for(i=0; i<CANT; i++)
    {
        printf("%s\t\t%d/%d/%d\t%.2f\t%d\n",emp[i].nombre,emp[i].nacimiento.dia,emp[i].nacimiento.mes,emp[i].nacimiento.anio,emp[i].salario,emp[i].legajo);
    }

    return 0;
}
