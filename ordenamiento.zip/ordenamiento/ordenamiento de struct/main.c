#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

#define CANT 1



int main()
{
    eEmpleado emp[CANT], aux;

    alta(emp,CANT);
    orden(emp,CANT);
    mostrar(emp,CANT);

    return 0;
}
