#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

void alta(eEmpleado emp[],int cantidad)
{
    int i;
    for(i=0; i<cantidad; i++)
    {

        printf("ingrese nombre y apellido del empleado: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",emp[i].nombre);
        printf("ingrese dia de nacimiento: \n");
        scanf("%d",&emp[i].nacimiento.dia);
        printf("ingrese mes de nacimiento: \n");
        scanf("%d",&emp[i].nacimiento.mes);
        printf("ingrese anio de nacimiento: \n");
        scanf("%d",&emp[i].nacimiento.anio);
        printf("ingrese salario de dicho empleado: \n");
        scanf("%f",&emp[i].salario);
        printf("por ultimo ingrese el numero de legajo: \n");
        scanf("%d",&emp[i].legajo);
        system("cls");

    }
    return;
}

void orden(eEmpleado emp[],int cantidad)
{
    eEmpleado aux;
    int i,j;
    for(i=0; i<cantidad-1; i++)
    {
        for(j=i+1; j<cantidad; j++)
        {
            if(emp[i].salario<emp[j].salario)
            {
                aux=emp[i];
                emp[i]=emp[j];
                emp[j]=aux;
            }
            else if(emp[i].salario==emp[j].salario)
            {
                if(strcmp(emp[i].nombre,emp[j].nombre)>0)
                {
                    aux=emp[i];
                    emp[i]=emp[j];
                    emp[j]=aux;
                }
            }
        }

    }
    return;
}

void mostrar(eEmpleado emp[],int cantidad)
{

    int i;
    printf("nombre: \t\tfecha de nac \tsalario \tN.legajo\n");
    for(i=0; i<cantidad; i++)
    {
        printf("%s\t\t%d/%d/%d\t%.2f\t%d\n",emp[i].nombre,emp[i].nacimiento.dia,emp[i].nacimiento.mes,emp[i].nacimiento.anio,emp[i].salario,emp[i].legajo);
    }
    return;
}
